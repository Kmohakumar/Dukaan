import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './Components/App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
{/*}.links{
  text-align: right;
  flex: 1;
  display: inline-block;

}
nav {

   
    position : sticky ;
    margin: auto  ;
    
    z-index : 1 ;
    display : flex ;
    align-items : center ;
}
.links ul li{
  list-style-type: none;
  display: inline-block;
  margin: 10px;
  font-weight: 1500;
}

.links ul{
  display: inline-block;
}
.down{position: absolute;
  width: 177px;
  height: 50px;
  left: 1103px;
  top: 20px;
  margin-right: 160px;
  
 
  
  background: #FFFFFF;
  border-radius: 4px;}
.ll {
width: 129px;
height: 26;
position: absolute;
list-style: none;
left: 10px;
top: 10px;
font-family: 'Galano Grotesque';
font-style: normal;
font-weight: 1100;
font-size: 18px;
line-height: 26px;
color: #146EB4;
text-decoration: none;
}
.Sign{
position: absolute;
width: 60px;
height: 26px;
margin-left: 1101px;
top: 32px;
text-decoration: none;

font-family: 'Galano Grotesque';
font-style: normal;
font-weight: 400;
font-size: 18px;
line-height: 26px;
}
.sign a{
text-decoration: none;
margin-right: 369px;

margin-top: 32px;
height: 60px;}
}*/}